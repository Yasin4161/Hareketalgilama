# Hareket Algılama Sistemi

Bu, gerçek zamanlı hareket algılama özelliklerine sahip modern bir web uygulamasıdır. Kamera beslemesini izler ve gelişmiş görsel takip yetenekleri sağlar.

## Özellikler

- 🎥 **Gerçek Zamanlı Kamera Erişimi**: WebRTC API kullanarak canlı video akışı
- 🔍 **Hareket Algılama**: Gelişmiş piksel karşılaştırma algoritması
- 🔴 **Görsel İşaretleme**: Hareket algılandığında kırmızı kare işaretleme
- 🔊 **Ses Uyarıları**: Her hareket algılamasında ses bildirimi
- ⚙️ **Hassaslık Kontrolü**: Ayarlanabilir algılama hassaslığı
- 📊 **Gerçek Zamanlı İstatistikler**: Algılama sayısı ve çalışma süresi takibi
- 🌙 **Karanlık Tema**: Modern karanlık arayüz
- 📱 **Mobil Uyumlu**: Responsive tasarım

## Teknoloji Yığını

### Frontend
- **React 18** + TypeScript
- **Tailwind CSS** + shadcn/ui bileşenleri
- **Vite** build aracı
- **TanStack Query** durum yönetimi
- **Wouter** routing

### Backend
- **Node.js** + Express.js
- **TypeScript** + ES modülleri
- **Drizzle ORM** + PostgreSQL

### Hareket Algılama
- **Canvas API** görüntü işleme
- **Web Audio API** ses uyarıları
- **WebRTC getUserMedia** kamera erişimi

## Kurulum

1. Repoyu klonlayın:
```bash
git clone https://github.com/kullaniciadi/hareket-algilama.git
cd hareket-algilama
```

2. Bağımlılıkları yükleyin:
```bash
npm install
```

3. Geliştirme sunucusunu başlatın:
```bash
npm run dev
```

4. Tarayıcınızda `http://localhost:5000` adresine gidin

## Kullanım

1. **Kamera İzni**: Uygulamayı açtığınızda kamera erişim izni verin
2. **Kamera Başlatma**: "Kamerayı Başlat" butonuna tıklayın
3. **Hareket Algılama**: "Algılamayı Başlat" ile hareket algılamayı aktifleştirin
4. **Ayarlar**: Hassaslık seviyesini ayarlayın ve ses/görsel ayarlarını kontrol edin

## Önemli Notlar

- **HTTPS Gereksinimi**: Kamera erişimi için güvenli bağlantı (HTTPS) gereklidir
- **Browser Desteği**: Modern tarayıcılar gereklidir (Chrome, Firefox, Safari, Edge)
- **Kamera Erişimi**: Sadece tek kamera kullanıcısı desteklenir
- **Gizlilik**: Hiçbir video kaydedilmez veya sunucuya gönderilmez

## Geliştirme

### Proje Yapısı
```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI bileşenleri
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Yardımcı kütüphaneler
│   │   └── pages/          # Sayfa bileşenleri
├── server/                 # Express backend
├── shared/                 # Ortak tip tanımları
└── public/                 # Static dosyalar
```

### Ana Bileşenler

- **useCamera**: Kamera stream yönetimi
- **useMotionDetection**: Hareket algılama algoritması
- **useAudio**: Ses uyarı sistemi
- **MotionDetector**: Ana uygulama bileşeni

### Build

Üretim build'i oluşturmak için:
```bash
npm run build
```

## Lisans

MIT License

## Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/yeni-ozellik`)
3. Değişikliklerinizi commit edin (`git commit -am 'Yeni özellik eklendi'`)
4. Branch'inizi push edin (`git push origin feature/yeni-ozellik`)
5. Pull Request oluşturun

## Sorun Giderme

### Kamera Erişim Sorunu
- Tarayıcı izinlerini kontrol edin
- HTTPS bağlantısı olduğundan emin olun
- Kameranın başka uygulamada kullanılmadığını kontrol edin

### Ses Sorunu
- Tarayıcı ses ayarlarını kontrol edin
- Ses düzeyini kontrol edin
- Ayarlar panelinden ses uyarısının açık olduğundan emin olun

## İletişim

Sorularınız için issue açabilir veya pull request gönderebilirsiniz.