import { MotionDetector } from "@/components/motion-detector";

export default function Home() {
  return (
    <div className="min-h-screen bg-[var(--dark-bg)] text-gray-100">
      <MotionDetector />
    </div>
  );
}
