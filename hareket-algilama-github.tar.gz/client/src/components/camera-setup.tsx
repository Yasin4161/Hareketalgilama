import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Video } from "lucide-react";

interface CameraSetupProps {
  onStartCamera: () => void;
  error?: string | null;
}

export function CameraSetup({ onStartCamera, error }: CameraSetupProps) {
  return (
    <div className="text-center py-16">
      <div className="max-w-md mx-auto">
        <div className="w-24 h-24 mx-auto mb-6 bg-[var(--dark-secondary)] rounded-full flex items-center justify-center">
          <Video className="w-12 h-12 text-gray-400" />
        </div>
        <h2 className="text-2xl font-bold mb-4">Kamera Erişimi Gerekli</h2>
        <p className="text-gray-400 mb-8">
          Hareket algılama için kameranıza erişim izni verin. Hiçbir video kaydedilmez veya aktarılmaz.
        </p>
        
        <div className="text-xs text-gray-500 mb-6 space-y-1">
          <p>• Tarayıcınızın kamera erişimine izin verdiğinden emin olun</p>
          <p>• Kameranızın başka bir uygulama tarafından kullanılmadığından emin olun</p>
          <p>• Bu sayfa güvenli (HTTPS) bağlantı kullanmalıdır</p>
        </div>
        
        {error && (
          <Card className="mb-6 bg-red-900/20 border-red-500/20">
            <CardContent className="pt-6">
              <p className="text-red-400 text-sm">{error}</p>
            </CardContent>
          </Card>
        )}
        
        <Button 
          onClick={onStartCamera}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 rounded-lg transition-colors duration-200 shadow-lg"
        >
          Kamerayı Başlat
        </Button>
      </div>
    </div>
  );
}
