# Motion Detection Web Application

## Overview

This is a modern web application built for real-time motion detection using webcam input. The application features a React frontend with a Node.js/Express backend, utilizing advanced camera APIs and canvas-based motion detection algorithms. The system is designed to provide real-time visual and audio alerts when motion is detected in the camera feed.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Build Tool**: Vite for fast development and optimized builds
- **State Management**: React hooks with TanStack Query for server state
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Development**: Hot reload with Vite middleware integration
- **Build**: esbuild for production bundling

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema**: User management with username/password authentication
- **Migrations**: Drizzle Kit for schema management

## Key Components

### Motion Detection System
- **Camera Access**: WebRTC getUserMedia API for camera stream
- **Motion Algorithm**: Canvas-based pixel difference detection
- **Real-time Processing**: RequestAnimationFrame for smooth detection
- **Sensitivity Control**: Adjustable threshold for motion detection
- **Visual Feedback**: Motion area highlighting on canvas overlay

### Audio System
- **Web Audio API**: Oscillator-based alert sound generation
- **User Control**: Toggle for enabling/disabling audio alerts
- **Browser Compatibility**: Fallback handling for unsupported browsers

### User Interface
- **Camera Setup**: Permission request and error handling interface
- **Monitoring Dashboard**: Real-time video feed with control panels
- **Settings Panel**: Sensitivity sliders and toggle controls
- **Statistics Display**: Detection count, uptime, and last detection time
- **Dark Theme**: Modern dark UI optimized for monitoring applications

### Custom Hooks
- **useCamera**: Camera stream management and error handling
- **useMotionDetection**: Motion detection algorithm and state
- **useAudio**: Sound generation and audio control
- **useMobile**: Responsive design utilities

## Data Flow

1. **Camera Initialization**: User grants camera permission through browser API
2. **Stream Processing**: Video stream rendered to HTML5 video element
3. **Motion Detection**: Canvas captures frames and compares pixel differences
4. **Alert System**: Motion triggers audio alerts and visual indicators
5. **Statistics Tracking**: Detection events logged with timestamps
6. **Real-time Updates**: UI reflects current detection state and statistics

## External Dependencies

### Core Runtime
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database ORM with schema validation
- **express**: Web server framework with middleware support

### Frontend Libraries
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/react-***: Accessible UI component primitives
- **wouter**: Lightweight routing for single-page applications
- **class-variance-authority**: Type-safe CSS class variations
- **clsx & tailwind-merge**: Conditional CSS class utilities

### Development Tools
- **vite**: Build tool with hot module replacement
- **typescript**: Static type checking and compilation
- **tailwindcss**: Utility-first CSS framework
- **esbuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite middleware integration with Express
- **TypeScript**: Real-time compilation and type checking
- **Path Aliases**: Simplified imports with @ and @shared prefixes
- **Error Overlay**: Runtime error modal for debugging

### Production Build
- **Frontend**: Vite builds React app to static assets
- **Backend**: esbuild bundles Node.js server with external dependencies
- **Output**: Separate dist folders for client and server builds
- **Deployment**: Single process serving both static files and API routes

### Environment Configuration
- **Database**: PostgreSQL connection via DATABASE_URL environment variable
- **Neon Integration**: Serverless PostgreSQL with connection pooling
- **Session Management**: PostgreSQL-based session store with connect-pg-simple

## Changelog

Changelog:
- July 04, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.