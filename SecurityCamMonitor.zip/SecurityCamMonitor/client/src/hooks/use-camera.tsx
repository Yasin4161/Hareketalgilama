import { useState, useRef, useCallback, useEffect } from "react";

export interface CameraHook {
  stream: MediaStream | null;
  isActive: boolean;
  error: string | null;
  videoRef: React.RefObject<HTMLVideoElement>;
  startCamera: () => Promise<void>;
  stopCamera: () => void;
}

export function useCamera(): CameraHook {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const startCamera = useCallback(async () => {
    try {
      setError(null);
      
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Browser does not support camera access. Please use HTTPS or a modern browser.');
      }
      
      console.log('Requesting camera access...');
      
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: { ideal: 'environment' }
        },
        audio: false
      });
      
      console.log('Camera access granted, setting up video stream...');
      setStream(mediaStream);
      
      // Set the video source immediately and let useEffect handle the activation
      console.log('Video stream obtained, will activate after component renders');
    } catch (err) {
      const error = err as Error;
      console.error('Error accessing camera:', error);
      
      let errorMessage = 'Kamera erişiminde hata oluştu';
      
      if (error.name === 'NotAllowedError') {
        errorMessage = 'Kamera erişim izni reddedildi. Lütfen tarayıcı ayarlarından izin verin.';
      } else if (error.name === 'NotFoundError') {
        errorMessage = 'Kamera bulunamadı. Lütfen kameranızın bağlı olduğundan emin olun.';
      } else if (error.name === 'NotReadableError') {
        errorMessage = 'Kamera başka bir uygulama tarafından kullanılıyor olabilir.';
      } else if (error.name === 'NotSupportedError') {
        errorMessage = 'Tarayıcınız kamera erişimini desteklemiyor. Lütfen güncel bir tarayıcı kullanın.';
      } else if (error.message.includes('HTTPS') || error.message.includes('secure')) {
        errorMessage = 'Kamera erişimi için güvenli bağlantı (HTTPS) gerekli. Lütfen sayfayı yenileyin.';
      } else {
        errorMessage = `Kamera hatası: ${error.message}`;
      }
      
      setError(errorMessage);
      setIsActive(false);
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    setIsActive(false);
    setError(null);
  }, [stream]);

  // Effect to handle video stream setup when stream and video element are both available
  useEffect(() => {
    if (stream && videoRef.current && !isActive) {
      console.log('Setting up video stream in useEffect...');
      
      const video = videoRef.current;
      video.srcObject = stream;
      
      const onLoadedMetadata = () => {
        console.log('Video metadata loaded in useEffect');
        video.removeEventListener('loadedmetadata', onLoadedMetadata);
        video.removeEventListener('error', onError);
        setIsActive(true);
      };
      
      const onError = (e: Event) => {
        console.error('Video error in useEffect:', e);
        video.removeEventListener('loadedmetadata', onLoadedMetadata);
        video.removeEventListener('error', onError);
        setError('Video yükleme hatası');
      };
      
      video.addEventListener('loadedmetadata', onLoadedMetadata);
      video.addEventListener('error', onError);
      
      // Force play to ensure stream starts
      video.play().catch(console.error);
      
      return () => {
        video.removeEventListener('loadedmetadata', onLoadedMetadata);
        video.removeEventListener('error', onError);
      };
    }
  }, [stream, isActive]);

  return {
    stream,
    isActive,
    error,
    videoRef,
    startCamera,
    stopCamera
  };
}
