import { useState, useRef, useCallback } from "react";

export interface AudioHook {
  isEnabled: boolean;
  setIsEnabled: (enabled: boolean) => void;
  playAlert: () => void;
}

export function useAudio(): AudioHook {
  const [isEnabled, setIsEnabled] = useState(true);
  const audioContextRef = useRef<AudioContext | null>(null);

  const initAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      try {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      } catch (e) {
        console.log('Web Audio API not supported');
      }
    }
  }, []);

  const playAlert = useCallback(() => {
    if (!isEnabled) {
      console.log('Audio is disabled, skipping sound');
      return;
    }
    
    console.log('Attempting to play alert sound...');
    
    initAudioContext();
    
    if (!audioContextRef.current) {
      console.log('No audio context available');
      return;
    }
    
    try {
      // Resume AudioContext if it's suspended (browser policy)
      if (audioContextRef.current.state === 'suspended') {
        console.log('Resuming suspended audio context...');
        audioContextRef.current.resume();
      }
      
      const oscillator = audioContextRef.current.createOscillator();
      const gainNode = audioContextRef.current.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContextRef.current.destination);
      
      // Create a more distinctive alarm sound
      oscillator.frequency.setValueAtTime(1000, audioContextRef.current.currentTime);
      oscillator.frequency.setValueAtTime(800, audioContextRef.current.currentTime + 0.1);
      oscillator.frequency.setValueAtTime(1000, audioContextRef.current.currentTime + 0.2);
      
      gainNode.gain.setValueAtTime(0.5, audioContextRef.current.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContextRef.current.currentTime + 0.3);
      
      oscillator.start(audioContextRef.current.currentTime);
      oscillator.stop(audioContextRef.current.currentTime + 0.3);
      
      console.log('Alert sound played successfully');
    } catch (e) {
      console.error('Error playing sound:', e);
    }
  }, [isEnabled, initAudioContext]);

  return {
    isEnabled,
    setIsEnabled,
    playAlert
  };
}
