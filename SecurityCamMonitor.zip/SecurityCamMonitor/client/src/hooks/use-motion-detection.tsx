import { useState, useRef, useCallback, useEffect } from "react";

export interface MotionArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface MotionDetectionHook {
  isActive: boolean;
  sensitivity: number;
  setSensitivity: (value: number) => void;
  detectionCount: number;
  lastDetection: Date | null;
  motionAreas: MotionArea[];
  startDetection: (videoElement: HTMLVideoElement, canvas: HTMLCanvasElement) => void;
  stopDetection: () => void;
  onMotionDetected?: () => void;
}

export function useMotionDetection(onMotionDetected?: () => void): MotionDetectionHook {
  const [isActive, setIsActive] = useState(false);
  const [sensitivity, setSensitivity] = useState(30);
  const [detectionCount, setDetectionCount] = useState(0);
  const [lastDetection, setLastDetection] = useState<Date | null>(null);
  const [motionAreas, setMotionAreas] = useState<MotionArea[]>([]);
  
  const animationFrameRef = useRef<number | null>(null);
  const previousFrameRef = useRef<ImageData | null>(null);
  const videoElementRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastSoundTimeRef = useRef<number>(0);

  const detectMotion = useCallback(() => {
    if (!isActive || !videoElementRef.current || !canvasRef.current) return;
    
    const video = videoElementRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx || !video.videoWidth) return;
    
    // Draw current frame
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const currentFrame = ctx.getImageData(0, 0, canvas.width, canvas.height);
    
    if (previousFrameRef.current) {
      const threshold = sensitivity * 2;
      let motionPixels = 0;
      const detectedAreas: MotionArea[] = [];
      const tempAreas: Array<{x: number, y: number, minX: number, maxX: number, minY: number, maxY: number}> = [];
      
      // Compare frames
      for (let i = 0; i < currentFrame.data.length; i += 4) {
        const rDiff = Math.abs(currentFrame.data[i] - previousFrameRef.current.data[i]);
        const gDiff = Math.abs(currentFrame.data[i + 1] - previousFrameRef.current.data[i + 1]);
        const bDiff = Math.abs(currentFrame.data[i + 2] - previousFrameRef.current.data[i + 2]);
        
        const avgDiff = (rDiff + gDiff + bDiff) / 3;
        
        if (avgDiff > threshold) {
          motionPixels++;
          
          // Calculate pixel coordinates
          const pixelIndex = i / 4;
          const x = pixelIndex % canvas.width;
          const y = Math.floor(pixelIndex / canvas.width);
          
          // Group nearby motion pixels into areas
          let foundArea = false;
          for (let area of tempAreas) {
            if (Math.abs(area.x - x) < 50 && Math.abs(area.y - y) < 50) {
              area.minX = Math.min(area.minX, x);
              area.maxX = Math.max(area.maxX, x);
              area.minY = Math.min(area.minY, y);
              area.maxY = Math.max(area.maxY, y);
              foundArea = true;
              break;
            }
          }
          
          if (!foundArea) {
            tempAreas.push({
              x: x, y: y,
              minX: x, maxX: x,
              minY: y, maxY: y
            });
          }
        }
      }
      
      // Convert temp areas to motion areas
      tempAreas.forEach(area => {
        const width = area.maxX - area.minX;
        const height = area.maxY - area.minY;
        
        if (width > 20 && height > 20) {
          detectedAreas.push({
            x: area.minX,
            y: area.minY,
            width,
            height
          });
        }
      });
      
      setMotionAreas(detectedAreas);
      
      // Trigger sound for any detected motion area (if there are red rectangles, play sound)
      if (detectedAreas.length > 0) {
        const now = Date.now();
        
        // Prevent too frequent sound alerts (minimum 500ms between sounds)
        if (now - lastSoundTimeRef.current > 500) {
          setDetectionCount(prev => prev + 1);
          setLastDetection(new Date());
          lastSoundTimeRef.current = now;
          onMotionDetected?.();
        }
      }
    }
    
    previousFrameRef.current = currentFrame;
    
    if (isActive) {
      animationFrameRef.current = requestAnimationFrame(detectMotion);
    }
  }, [isActive, sensitivity, onMotionDetected]);

  const startDetection = useCallback((videoElement: HTMLVideoElement, canvas: HTMLCanvasElement) => {
    videoElementRef.current = videoElement;
    canvasRef.current = canvas;
    
    // Set canvas dimensions to match video
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    
    setIsActive(true);
    previousFrameRef.current = null; // Reset frame comparison
  }, []);

  const stopDetection = useCallback(() => {
    setIsActive(false);
    setMotionAreas([]);
    
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
  }, []);

  // Start detection loop when active
  useEffect(() => {
    if (isActive) {
      detectMotion();
    }
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isActive, detectMotion]);

  return {
    isActive,
    sensitivity,
    setSensitivity,
    detectionCount,
    lastDetection,
    motionAreas,
    startDetection,
    stopDetection,
    onMotionDetected
  };
}
