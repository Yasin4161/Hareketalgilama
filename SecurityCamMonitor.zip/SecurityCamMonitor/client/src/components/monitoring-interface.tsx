import { useRef, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Settings, BarChart3, Play, Square } from "lucide-react";
import { MotionArea } from "@/hooks/use-motion-detection";

interface MonitoringInterfaceProps {
  videoRef: React.RefObject<HTMLVideoElement>;
  isDetectionActive: boolean;
  sensitivity: number;
  setSensitivity: (value: number) => void;
  detectionCount: number;
  lastDetection: Date | null;
  motionAreas: MotionArea[];
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  visualEnabled: boolean;
  setVisualEnabled: (enabled: boolean) => void;
  uptime: string;
  resolution: string;
  onToggleDetection: () => void;
  onStopCamera: () => void;
}

export function MonitoringInterface({
  videoRef,
  isDetectionActive,
  sensitivity,
  setSensitivity,
  detectionCount,
  lastDetection,
  motionAreas,
  soundEnabled,
  setSoundEnabled,
  visualEnabled,
  setVisualEnabled,
  uptime,
  resolution,
  onToggleDetection,
  onStopCamera
}: MonitoringInterfaceProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isMotionDetected, setIsMotionDetected] = useState(false);

  // Flash effect when motion is detected
  useEffect(() => {
    if (motionAreas.length > 0) {
      setIsMotionDetected(true);
      const timer = setTimeout(() => setIsMotionDetected(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [motionAreas]);

  return (
    <div>
      {/* Video Container */}
      <div className="bg-[var(--dark-secondary)] rounded-xl p-6 mb-6">
        <div className={`relative aspect-video bg-black rounded-lg overflow-hidden ${isMotionDetected ? 'motion-detection-active' : ''}`}>
          <video 
            ref={videoRef}
            className="w-full h-full object-cover" 
            autoPlay 
            muted 
            playsInline 
          />
          <canvas 
            ref={canvasRef}
            className="absolute inset-0 w-full h-full pointer-events-none opacity-0"
          />
          
          {/* Motion Detection Overlays */}
          {visualEnabled && motionAreas.map((area, index) => (
            <div
              key={index}
              className="detection-overlay"
              style={{
                left: `${(area.x / (videoRef.current?.videoWidth || 1)) * 100}%`,
                top: `${(area.y / (videoRef.current?.videoHeight || 1)) * 100}%`,
                width: `${(area.width / (videoRef.current?.videoWidth || 1)) * 100}%`,
                height: `${(area.height / (videoRef.current?.videoHeight || 1)) * 100}%`,
              }}
            />
          ))}
          
          {/* Video Controls Overlay */}
          <div className="absolute bottom-4 left-4 flex items-center space-x-3">
            <div className="bg-black bg-opacity-70 text-white px-3 py-1 rounded-full text-sm font-medium">
              <span>{resolution}</span>
            </div>
            {isDetectionActive && (
              <div className="bg-red-600 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-2">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                <span>Algılama Aktif</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Control Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Detection Controls */}
        <Card className="bg-[var(--dark-secondary)] border-gray-700">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Settings className="w-5 h-5 mr-2" />
              Algılama Kontrolü
            </h3>
            
            <div className="space-y-4">
              <Button 
                onClick={onToggleDetection}
                className={`w-full font-semibold py-3 px-4 rounded-lg transition-colors duration-200 ${
                  isDetectionActive 
                    ? 'bg-red-600 hover:bg-red-700' 
                    : 'bg-emerald-600 hover:bg-emerald-700'
                }`}
              >
                {isDetectionActive ? (
                  <>
                    <Square className="w-4 h-4 mr-2" />
                    Algılamayı Durdur
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Algılamayı Başlat
                  </>
                )}
              </Button>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">Hassaslık</label>
                <Slider
                  value={[sensitivity]}
                  onValueChange={(value) => setSensitivity(value[0])}
                  min={10}
                  max={100}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>Düşük</span>
                  <span>{sensitivity}</span>
                  <span>Yüksek</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Statistics */}
        <Card className="bg-[var(--dark-secondary)] border-gray-700">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <BarChart3 className="w-5 h-5 mr-2" />
              İstatistikler
            </h3>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-300">Toplam Algılama:</span>
                <span className="text-xl font-bold text-emerald-400">{detectionCount}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-300">Son Algılama:</span>
                <span className="text-sm text-gray-400">
                  {lastDetection ? lastDetection.toLocaleTimeString('tr-TR') : 'Henüz yok'}
                </span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-300">Çalışma Süresi:</span>
                <span className="text-sm text-gray-400">{uptime}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card className="bg-[var(--dark-secondary)] border-gray-700">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Settings className="w-5 h-5 mr-2" />
              Ayarlar
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-300">Ses Uyarısı</label>
                <Switch
                  checked={soundEnabled}
                  onCheckedChange={setSoundEnabled}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-300">Görsel İşaretleme</label>
                <Switch
                  checked={visualEnabled}
                  onCheckedChange={setVisualEnabled}
                />
              </div>
              
              <Button 
                onClick={onStopCamera}
                variant="destructive"
                className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200"
              >
                Kamerayı Durdur
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
