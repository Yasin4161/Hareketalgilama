import { useState, useEffect } from "react";
import { Video } from "lucide-react";
import { useCamera } from "@/hooks/use-camera";
import { useMotionDetection } from "@/hooks/use-motion-detection";
import { useAudio } from "@/hooks/use-audio";
import { CameraSetup } from "./camera-setup";
import { MonitoringInterface } from "./monitoring-interface";

export function MotionDetector() {
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [uptime, setUptime] = useState("00:00:00");
  const [visualEnabled, setVisualEnabled] = useState(true);

  const camera = useCamera();
  const audio = useAudio();
  
  const motionDetection = useMotionDetection(() => {
    console.log('Motion detected! Playing alert sound...');
    audio.playAlert();
  });

  // Update uptime
  useEffect(() => {
    if (!startTime) return;
    
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime.getTime();
      const hours = Math.floor(elapsed / 3600000);
      const minutes = Math.floor((elapsed % 3600000) / 60000);
      const seconds = Math.floor((elapsed % 60000) / 1000);
      
      setUptime(
        `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      );
    }, 1000);
    
    return () => clearInterval(interval);
  }, [startTime]);

  const handleStartCamera = async () => {
    console.log('Starting camera from motion detector...');
    try {
      await camera.startCamera();
      console.log('Camera started successfully, camera.isActive:', camera.isActive);
      
      // Initialize audio context after user interaction
      console.log('Initializing audio context after user interaction...');
      audio.playAlert(); // Test sound to activate audio context
      
      setStartTime(new Date());
    } catch (error) {
      console.error('Failed to start camera:', error);
    }
  };

  const handleStopCamera = () => {
    motionDetection.stopDetection();
    camera.stopCamera();
    setStartTime(null);
    setUptime("00:00:00");
  };

  const handleToggleDetection = () => {
    if (!camera.videoRef.current) return;
    
    if (motionDetection.isActive) {
      motionDetection.stopDetection();
    } else {
      const canvas = document.createElement('canvas');
      motionDetection.startDetection(camera.videoRef.current, canvas);
    }
  };

  const getResolution = () => {
    if (camera.videoRef.current && camera.videoRef.current.videoWidth) {
      return `${camera.videoRef.current.videoWidth}x${camera.videoRef.current.videoHeight}`;
    }
    return "Yükleniyor...";
  };

  const getStatusInfo = () => {
    if (!camera.isActive) {
      return { color: 'bg-gray-500', text: 'Hazır Değil' };
    } else if (motionDetection.isActive) {
      return { color: 'bg-red-500', text: 'Algılama Aktif' };
    } else {
      return { color: 'bg-emerald-500', text: 'Hazır' };
    }
  };

  const status = getStatusInfo();

  return (
    <div>
      {/* Header */}
      <header className="bg-[var(--dark-secondary)] border-b border-gray-700 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Video className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Hareket Algılama Sistemi</h1>
              <p className="text-sm text-gray-400">Gerçek Zamanlı İzleme</p>
            </div>
          </div>
          
          {/* Status Badge */}
          <div className="flex items-center space-x-2 px-4 py-2 rounded-full bg-gray-700 border border-gray-600">
            <div className={`w-3 h-3 rounded-full ${status.color}`}></div>
            <span className="text-sm font-medium">{status.text}</span>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-8">

        
        {!camera.isActive && !camera.stream ? (
          <CameraSetup onStartCamera={handleStartCamera} error={camera.error} />
        ) : (
          <MonitoringInterface
            videoRef={camera.videoRef}
            isDetectionActive={motionDetection.isActive}
            sensitivity={motionDetection.sensitivity}
            setSensitivity={motionDetection.setSensitivity}
            detectionCount={motionDetection.detectionCount}
            lastDetection={motionDetection.lastDetection}
            motionAreas={visualEnabled ? motionDetection.motionAreas : []}
            soundEnabled={audio.isEnabled}
            setSoundEnabled={audio.setIsEnabled}
            visualEnabled={visualEnabled}
            setVisualEnabled={setVisualEnabled}
            uptime={uptime}
            resolution={getResolution()}
            onToggleDetection={handleToggleDetection}
            onStopCamera={handleStopCamera}
          />
        )}
      </main>
    </div>
  );
}
